Assignment - Week 1
-------------------

Use the commands below to compile/run the project:

    $ javac Main.java
    $ java Main

*Note*: The files `matrix1.txt` and `matrix2.txt` contain the matrices used for
the project. You can modify their content, as long as you maintain their
filenames unchanged.
